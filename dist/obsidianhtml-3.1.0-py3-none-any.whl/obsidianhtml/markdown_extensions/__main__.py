from .CustomTocExtension import unescape

print(unescape('bla'))