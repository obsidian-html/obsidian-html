from obsidianhtml import main

main()

