This note was linked, but never created (or removed)

<a href="javascript:history.back()">Go Back</a> or <a href="{html_url_prefix}/" style="margin-left: unset;">Go to Home</a>.

