To run (test) this code without running ObsidianHtml, try this:

``` python
# compile html files from units
python -m obsidianhtml.gui compile

# run the gui
python -m obsidianhtml.gui

# compile first and then run
python -m obsidianhtml.gui compile+run
```

> If the obsidianhtml/src/installer/dist folder is absent it will run compile 
> regardless!